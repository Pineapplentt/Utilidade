
package hcs.view;

public class Verificacao {
    private static Integer intVerificacao;
    
    public static Integer getIntVerificacao() {
        return intVerificacao;
    }

    public void setIntVerificacao(Integer intVerificacao) {
        Verificacao.intVerificacao = intVerificacao;
    }
}
